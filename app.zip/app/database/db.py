from core.imports import *
import sqlite3
from datetime import date

def get_connect():
    conn = sqlite3.connect('funcionarios.db')
    conn.row_factory = sqlite3.Row
    return conn

def db_init():
    with get_connect() as conn:
        cursor = conn.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS funcionario (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nome TEXT NOT NULL,
                cpf TEXT NOT NULL,
                cargo TEXT NOT NULL,
                senha_hash TEXT NOT NULL,
                data_contratacao DATE NOT NULL,
                ativo INTEGER
            )
        ''')
        conn.commit()

def add_funcionario(nome, cpf, cargo, senhaHash, data_contratacao=None, ativo=1):
    if data_contratacao is None:
        data_contratacao = date.today().isoformat()  # YYYY-MM-DD

    conn = get_connect()
    cursor = conn.cursor()
    cursor.execute('''
        INSERT INTO funcionario (nome, cpf, cargo, senhaHash, data_contratacao, ativo)
        VALUES (?, ?, ?, ?, ?, ?)
    ''', (nome, cpf, cargo, senhaHash, data_contratacao, ativo))
    conn.commit()
    conn.close()
