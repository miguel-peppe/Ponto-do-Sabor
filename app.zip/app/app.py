from core.imports import *
from core.userAuth import Funcionario
from database.db import *
from flask_login import LoginManager


app = Flask(__name__)
app.secret_key = 'chave-secreta'  

login_manager = LoginManager()
login_manager.login_view = 'login'  # redireciona para /login se não logado
login_manager.init_app(app)

@app.route('/')
def home():
    return render_template('home.html')


""" ======================== Funcionarios ======================== """
@app.route('/cadastrar')
def cadastrar():
    return render_template('cadastrar_func.html')  

@app.route('/cadastrar_funcionario', methods=['POST'])
def cadastrar_funcionario():
    nome = request.form['nome']
    cpf = request.form['cpf']
    cargo = request.form['cargo']
    senha = request.form['senha']
    data = request.form.get('data_contratacao')
    senhaHash = generate_password_hash(senha)

    if not validar_cpf(cpf):
        erro = "CPF inválido. Verifique e tente novamente."
        return render_template('cadastrar_func.html', erro=erro, nome=nome, cpf=cpf, cargo=cargo, senha=senha)

    try:
        add_funcionario(nome, cpf, cargo, senhaHash, data)
        return redirect(url_for('home'))
    except Exception as e:
        erro = f"Erro ao cadastrar funcionário: {e}"
        return render_template('cadastrar_func.html', erro=erro)

@app.route('/excluir')
def excluir():
    return render_template('excluir_func.html')

@app.route('/excluir_funcionario', methods=['POST'])
def excluir_funcionario():
    id = request.form['id']
    
    conn = get_connect()
    cursor = conn.cursor()
    cursor.execute('UPDATE funcionario SET ativo = 0 WHERE id = ?', (id,))
    conn.commit()
    conn.close()
    return redirect(url_for('home'))

@app.route('/listar')
def listar():
    conn = get_connect()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM funcionario WHERE ativo = 1')
    funcionarios = cursor.fetchall()
    conn.close()

    return render_template('listar_funcionario.html', funcionarios=funcionarios)


""" ======================== Login ======================== """
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        cpf = request.form['cpf']
        senha = request.form['senha']
        
        conn = get_connect()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM funcionario WHERE cpf = ? AND ativo = 1", (cpf,))
        user = cursor.fetchone()
        conn.close()

        if user and check_password_hash(user['senha_hash'], senha):
            user_obj = Funcionario(user['id'], user['nome'], user['cpf'], user['cargo'])
            login_user(user_obj)
            return redirect(url_for('home'))

        return render_template('login.html', erro="CPF ou senha inválidos.")

    return render_template('login.html')

@login_manager.user_loader
def load_user(user_id):
    conn = get_connect()
    cursor = conn.cursor()
    cursor.execute("SELECT id, nome, cpf, cargo FROM funcionario WHERE id = ?", (user_id,))
    user = cursor.fetchone()
    conn.close()

    if user:
        return Funcionario(user['id'], user['nome'], user['cpf'], user['cargo'])
    return None



if __name__ == "__main__":
    db_init()  # Cria tabela se não existir
    app.run(debug=True, port=8080)
